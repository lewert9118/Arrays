//: [Previous](@previous)
//: # Learning Outcomes
//: By the end of this unit, students should be able to
//: 1. Build an array.
//: 1. Append an array.
//: 1. Remove an item in an array.
//: ## Vocabulary
//: * Array
//: * Property
//: * Count
//: * Append
//: * Mutable and Immutable
//:
//: ## Containers for Information
//: Many times we have to remember or manage an entire list of things.  For example, suppose I wanted to maintain a list of all my favorite superheroes.  How would we do this using coding constructs we already know?  Well, if I had 8 favorite superheroes, we could do something like this:
var superHero1 = "Superman"
var superHero2 = "Wonder Woman"
var superHero3 = "The Hulk"
var superHero4 = "Bat Girl"
var superHero5 = "Spiderman"
var superHero6 = "Captain America"
var superHero7 = "Flash"
var superHero8 = "Flame"
//: But what if I had 20 superheroes that I liked?  And what if I wanted to use a bit of code to print out all their names?  Would each superHero have to be called individually? What would happen if we wanted to store 800 superheroes rather than 8?  Clearly, our code would become unwieldy very quickly.  
//: This is where arrays come to the rescue.  An array is an ordered list of objects.  Rather than creating a lot of variables with different names to store a list of items (like in the example above), we only create one object to hold all that information. It would look like this in code:
let mySuperHeroesList = ["Superman", "Wonder Woman", "The Hulk", "Bat Girl", "Spiderman", "Captain America", "Flash", "Flame"]
//: Much simpler, yes? Here’s a visual of what the array code looks like in storage:
//: ![Arrays](Arrays1.png "Arrays")
//: In the diagram above, we have an array made up of 8 objects.  In this case, the objects are all of type String.  Each element in an array has an index, which is the location in the array where you can find that element. The index of the first element in an array is always zero, and will count upwards for each subsequent element. So in an array of four elements, the indices would be 0, 1, 2, and 3. 
//: It’s important to note that an array will always keep these items in this order. This is really useful for when you want to refer to a list of items in the same order every time - for example, a grocery list or a set of instructions.

//: ## Calling Your Array
//: Now, if we want to print out all of our superheroes, we could use a set of instructions called a for-in loop. This is a bit of code that loops back through something a set number of times. Don’t worry about learning the nuances of a for-in loop right now - there’s a whole other section on loops. Here, we’re just using it as an example to show how using an array provides cleaner code:
for i in 0...7
{
    print(mySuperHeroesList[i])
}
//: In the example above, the program will loop back through your array - the container - called mySuperHeroesList. It’s much easier to call an array to list out things rather than listing them out by hand.
//: The most popular property of an Array is count.  It returns the number of items in the array.  If you look back at our for-in loop example, we wrote it to execute the contents of the for-in loop eight times because we knew that the array had eight elements.  However, our code could be more resilient to change and smarter about this by using the count property:

for i in 0..<mySuperHeroesList.count
{
    print(mySuperHeroesList[i])
}

//: In the example above, the for-in loop would execute once for every item in the array. This is a really useful thing to do when we want to perform some action on each element in an array without having to manually keep track of its contents.

//: ## Mutability
//: An array is immutable if it is declared using let.  Remember - using 'let' creates an object that cannot be changed later on.  To create an array that can be changed, we declare the array using 'var'.  In the example below we declare a mutable array of mySuperHeroes with 3 superheroes to start.
var SuperHeroes = ["Superman", "Spiderman", "Wonder Woman"]

//: We then add a 4th superhero after the declaration by using the append method:
SuperHeroes.append("The Hulk")
//: Note: a method is a an action that you can perform on a specific type of object. For example, the 'Array' type has a method called 'append' that will add a specified element to that array.
//: Once this method is executed, our array will now have 4 elements.  
//: Additionally, we can remove any element of the array by using the removeAtIndex method. Let's say we wanted to remove "Spiderman" from our list, we could accomplish this with the following:
SuperHeroes.removeAtIndex(1)
print(SuperHeroes)
//: Notice now that our SuperHeroes array doesn't contain "Spiderman" anymore!

//: ## To Wrap Up
//: We can create an array:
var myHeroes = ["Superman", "Spiderman", "Wonder Woman"]
//: We can append an array:
myHeroes.append("The Hulk")
//: And we can remove elements from arrays:
myHeroes.removeAtIndex(1)
//: Practice building arrays, appending arrays, and removing items from arrays in Xcode.
